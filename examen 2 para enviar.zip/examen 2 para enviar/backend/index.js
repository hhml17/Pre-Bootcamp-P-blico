// index.js
import './server.js';