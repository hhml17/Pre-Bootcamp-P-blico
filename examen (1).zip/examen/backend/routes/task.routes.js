// routes/task.routes.js
import express from 'express';
import { getAllTasks, createTask, updateTask, deleteTask } from '../controllers/task.controller.js';
import authMiddleware from '../middlewares/auth.middleware.js';

const router = express.Router();

router.get('/', authMiddleware, getAllTasks); // Obtener todas las tareas
router.post('/', authMiddleware, createTask); // Crear una nueva tarea
router.put('/:id', authMiddleware, updateTask); // Actualizar tarea
router.delete('/:id', authMiddleware, deleteTask); // Eliminar tarea
router.get('/:id', authMiddleware, getTaskById);

export default router;