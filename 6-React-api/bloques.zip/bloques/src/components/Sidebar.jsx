import React from 'react';

function Sidebar() {
  return (
    <aside className="sidebar">
      {/* Bloque azul claro */}
    </aside>
  );
}

export default Sidebar;
