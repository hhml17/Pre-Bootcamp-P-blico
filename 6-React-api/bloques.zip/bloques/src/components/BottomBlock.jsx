import React from 'react';

function BottomBlock() {
  return (
    <div className="bottom-block">
      {/* Bloque verde */}
    </div>
  );
}

export default BottomBlock;
