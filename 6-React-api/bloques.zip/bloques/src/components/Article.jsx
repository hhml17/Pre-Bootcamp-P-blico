import React from 'react';

function Article() {
  return (
    <article>
      <h2>Título del Artículo</h2>
      <p>Este es un artículo de ejemplo para demostrar la estructura de bloques en React.</p>
    </article>
  );
}

export default Article;
