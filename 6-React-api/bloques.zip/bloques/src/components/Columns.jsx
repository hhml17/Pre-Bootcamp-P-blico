import React from 'react';

function Columns() {
  return (
    <div className="columns">
      <div className="column"></div>
      <div className="column"></div>
      <div className="column"></div>
    </div>
  );
}

export default Columns;
