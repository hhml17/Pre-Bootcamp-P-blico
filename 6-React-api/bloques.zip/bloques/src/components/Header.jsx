import React from 'react';

function Header() {
  return (
    <header className="header">
      {/* Este es el bloque amarillo */}
    </header>
  );
}

export default Header;
